<?php
$x = "Hello world!";
$x = null;
var_dump($x);
?>  