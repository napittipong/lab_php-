<!DOCTYPE html>
<html>
<body>
<?php
echo strpos("Hello world!", "world");
?> 
</body>
</html>