<!DOCTYPE html>
<html>
<body>

<?php
$x = 10;  
echo $x;
?>  
<br>
<?php
$x = 20;  
$x += 100;
echo $x;
?> 
<br>
<?php
$x = 50;
$x -= 30;
echo $x;
?> 
<br> 
<?php
$x = 10;  
$y = 6;
echo $x * $y;
?>  
<br>
<?php
$x = 10;
$x /= 5;
echo $x;
?>  
<br>
<?php
$x = 15;
$x %= 4;
echo $x;
?>  



</body>
</html>
