<!DOCTYPE html>
<html>
<body>

<?php
echo(abs(-6.7));
?>

</body>
</html>