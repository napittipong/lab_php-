<!DOCTYPE html>
<html>
<body>

<?php
echo(rand());
?>

</body>
</html>