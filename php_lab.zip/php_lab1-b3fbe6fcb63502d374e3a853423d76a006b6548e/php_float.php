<?php
$x = 10.365;
var_dump($x);
?>