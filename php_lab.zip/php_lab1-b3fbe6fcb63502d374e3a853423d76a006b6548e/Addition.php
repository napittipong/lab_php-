<!DOCTYPE html>
<html>
<body>

<?php
$x = 20;  
$y = 14;

echo $x + $y;
?>  

</body>
</html>