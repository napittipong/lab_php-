<!DOCTYPE html>
<html>
<body>

<?php
echo strlen("Hello world!");
?> 
 
</body>
</html>